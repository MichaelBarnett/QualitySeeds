return
{
  width = 71,
  height = 69,
  shift = util.by_pixel(0,-3),
  line_length = 1,
}
