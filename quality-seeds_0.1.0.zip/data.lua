require ("util")

data.extend{
  {
    type = "recipe-category",
    name = "cultivation_yumako"
  },
  {
    type = "recipe-category",
    name = "cultivation_jellynut"
  },
  { 
    type = "collision-layer", 
    name = "growable_yumako"
  },
  { 
    type = "collision-layer", 
    name = "growable_jellynut"
  }
}


-- Define a new collision mask, to update the masked collisions of the soils.
local tile_collision_masks = {}
tile_collision_masks.growable_yumako = function()
  return
  {layers={
    ground_tile=true,
    growable_yumako=true,
  }}
end

tile_collision_masks.growable_jellynut = function()
  return
  {layers={
    ground_tile=true,
    growable_jellynut=true,
  }}
end

data.raw["tile"]["natural-yumako-soil"].collision_mask = tile_collision_masks.growable_yumako()
data.raw["tile"]["artificial-yumako-soil"].collision_mask = tile_collision_masks.growable_yumako()
data.raw["tile"]["overgrowth-yumako-soil"].collision_mask = tile_collision_masks.growable_yumako()
data.raw["tile"]["natural-jellynut-soil"].collision_mask = tile_collision_masks.growable_jellynut()
data.raw["tile"]["artificial-jellynut-soil"].collision_mask = tile_collision_masks.growable_jellynut()
data.raw["tile"]["overgrowth-jellynut-soil"].collision_mask = tile_collision_masks.growable_jellynut()

local function create_quality_tree(tree_name, seed_name, fruit_name)
  local tree = data.raw["plant"][tree_name]
  if not tree then
    log("Tree prototype not found: " .. tree_name)
    return
  end

  local seed = data.raw["item"][seed_name]
  if not seed then
    log("Fruit prototype not found: " .. seed_name)
    return
  end

  local fruit = data.raw["capsule"][fruit_name]
  if not fruit then
    log("Fruit not found: " .. fruit_name)
    return
  end

  local chamber = data.raw["assembling-machine"]["biochamber"]
  if not chamber then
    log("Biochamber prototype not found: " .. seed_name)
    return
  end

  local cultivator = table.deepcopy(data.raw["assembling-machine"]["biochamber"])
  local agricultural_graphics = table.deepcopy(data.raw["agricultural-tower"]["agricultural-tower"]["graphics_set"])
  agricultural_graphics.animation.layers =
  {
    util.sprite_load("__quality-seeds__/graphics/entity/cultivator",
    {
      priority = "high",
      animation_speed = 0.25,
      frame_count = 64,
      scale = 0.5
    }),
    util.sprite_load("__space-age__/graphics/entity/agricultural-tower/agricultural-tower-base-shadow",
    {
      priority = "high",
      frame_count = 1,
      repeat_count = 64,
      draw_as_shadow = true,
      scale = 0.5
    })
  }

  local cultivator_name = fruit_name .. "-greenhouse"
  local processing_tint = {}
  cultivator.name = cultivator_name

  if fruit_name == "yumako" then
    cultivator.tile_buildability_rules =
    {
      {
        area = {{-1.0, -1.0}, {1.0, 1.0}}, 
        required_tiles = {
          "natural-"..fruit_name.."-soil",
          "artificial-"..fruit_name.."-soil",
          "overgrowth-"..fruit_name.."-soil",
          layers={growable_yumako=true}
        },
        remove_on_collision = true
      },
    }
    processing_tint = {
      primary = {r = 1.040, g = 0.186, b = 0.040, a = 1.000}, -- #0a2fffff
      secondary = {r = 1.000, g = 0.400, b = 0.200, a = 1.000}, -- #3366ffff
      tertiary = {r = 1.000, g = 0.651, b = 0.600, a = 1.000}, -- #99a6ffff
      quaternary = {r = 0.500, g = 0.300, b = 0.100, a = 1.000}, -- #194c7fff
    }
  end
  if fruit_name == "jellynut" then
    cultivator.tile_buildability_rules =
    {
      {
        area = {{-1.0, -1.0}, {1.0, 1.0}}, 
        required_tiles = {
          "natural-"..fruit_name.."-soil",
          "artificial-"..fruit_name.."-soil",
          "overgrowth-"..fruit_name.."-soil",
          layers={growable_jellynut=true}
        },
        remove_on_collision = true
      },
    }
    processing_tint = {
      primary = {r = 0.540, g = 0.186, b = 1.000, a = 1.000},
      secondary = {r = 0.700, g = 0.400, b = 1.000, a = 1.000},
      tertiary = {r = 1.000, g = 0.651, b = 1.000, a = 1.000},
      quaternary = {r = 0.600, g = 0.300, b = 0.500, a = 1.000},
    }
  end

  cultivator.crafting_categories = {"cultivation_"..fruit_name}
  cultivator.minable = {mining_time = 0.1, result = cultivator_name}
  cultivator.fast_replaceable_group = cultivator_name
  cultivator.place_result = cultivator_name
  cultivator.circuit_connector = circuit_connector_definitions[cultivator_name]
  cultivator.energy_source.emissions_per_minute = {spores = 100} -- GMO fruit be TASTY.
  cultivator.graphics_set = agricultural_graphics
  cultivator.fluid_boxes =
  {
    {
      production_type = "input",
      volume = 1000,
      pipe_connections =
      {
        {
          flow_direction="input",
          direction = defines.direction.north,
          position = {0, -1}
        }
      }
    },
    {
      production_type = "output",
      volume = 1000,
      pipe_connections =
      {
        {
          flow_direction = "output",
          direction = defines.direction.south,
          position = {0, 1}
        }
      }
    }
  }

  local cultivator_recipe = {
    type = "recipe",
    name = cultivator_name,
    category = "organic-or-assembling",
    surface_conditions =
    {
      {
        property = "pressure",
        min = 2000,
        max = 2000
      }
    },
    energy_required = 20,
    ingredients =
    {
      {type = "item", name = "nutrients", amount = 5},
      {type = "item", name = seed_name, amount = 1},
      {type = "item", name = "iron-plate", amount = 20},
      {type = "item", name = "electronic-circuit", amount = 5},
      {type = "item", name = "artificial-"..fruit_name.."-soil", amount = 9}
    },
    results = {{type="item", name=cultivator_name, amount=1}},
    enabled = false,
    icons = {
      {  
        icon = "__quality-seeds__/graphics/icons/cultivator-"..fruit_name..".png"
      }
    }
  }

  local cultivator_item = table.deepcopy(data.raw["item"]["biochamber"])
  cultivator_item.name = cultivator_name
  cultivator_item.place_result = cultivator_name
  cultivator.icon = "__quality-seeds__/graphics/icons/cultivator-"..fruit_name..".png"

  -- create a test recipe prototype from scratch
  local recipe_gmo = {
    type = "recipe",
    name = "gmo-" .. seed_name,
    category = "cryogenics",
    enabled = false,
    ingredients = {
      {type = "item", name = seed_name, amount = 1},
      {type = "item", name = "uranium-235", amount = 1},
      {type = "fluid", name = "fluoroketone-cold", amount = 10, ignored_by_stats = 10}
    },
    energy_required = 10,
    results = {
      {type = "item", name = seed_name, amount = 1},
      {type = "item", name = "uranium-238", amount = 1},
      {type = "fluid", name = "fluoroketone-hot", amount = 10, ignored_by_stats = 10, ignored_by_productivity = 10}
    },
    main_product = seed_name,
    allow_productivity = false,
    crafting_machine_tint = {
      primary = {r = 0.040, g = 1.000, b = 0.186, a = 1.000}, -- #0a2fffff
      secondary = {r = 0.200, g = 1.000, b = 0.400, a = 1.000}, -- #3366ffff
      tertiary = {r = 0.600, g = 1.000, b = 0.651, a = 1.000}, -- #99a6ffff
      quaternary = {r = 0.100, g = 0.500, b = 0.300, a = 1.000}, -- #194c7fff
    },
    icons = {
      {
        icon = "__quality-seeds__/graphics/icons/gmo-"..fruit_name..".png"
      }
    }
  }

  -- create a test recipe prototype from scratch
  local recipe_cultivate = {
    type = "recipe",
    name = "cultivate-" .. fruit_name,
    category = "cultivation_"..fruit_name,
    enabled = false,
    ingredients = {
      {type = "item", name = seed_name, amount = 1},
      {type = "fluid", name = "water", amount = 100},
    },
    energy_required = 100,
    results = {
      {type = "item", name = fruit_name, amount = 20},
      {type = "fluid", name = "steam", amount = 100, temperature = 15},
    },
    main_product = fruit_name,
    allow_productivity = true,
    crafting_machine_tint = processing_tint,
  }

  data:extend{recipe_gmo, recipe_cultivate, cultivator, cultivator_item, cultivator_recipe}

end

create_quality_tree("yumako-tree","yumako-seed","yumako")
create_quality_tree("jellystem","jellynut-seed","jellynut")

--Unlock Sciences:
data:extend({
  {
      type = "technology",
      name = "fruit-cultivation",
      icon = "__quality-seeds__/graphics/technology/cultivars.png", -- Path to your tech icon
      icon_size = 256, -- Adjust to match your icon's size
      prerequisites = {"agricultural-science-pack"}, -- Add appropriate prerequisite techs
      unit = {
        count = 500,
        ingredients =
        {
          {"automation-science-pack",   1},
          {"logistic-science-pack",     1},
          {"chemical-science-pack",     1},
          {"space-science-pack",        1},
          {"agricultural-science-pack", 1}
        },
        time = 60
      },
      effects = {
        {type = "unlock-recipe", recipe = "yumako-greenhouse"},
        {type = "unlock-recipe", recipe = "jellynut-greenhouse"},
        {type = "unlock-recipe", recipe = "cultivate-yumako"},
        {type = "unlock-recipe", recipe = "cultivate-jellynut"},
          -- Add more recipes and structures as needed
      },
  },
  {
    type = "technology",
    name = "radiation-breeding",
    icon = "__quality-seeds__/graphics/technology/radiative-breeding.png", -- Path to your tech icon
    icon_size = 256, -- Adjust to match your icon's size
    prerequisites = {"fruit-cultivation","cryogenic-plant"}, -- Add appropriate prerequisite techs
    unit = {
      count = 2000,
      ingredients =
      {
        {"automation-science-pack",   1},
        {"logistic-science-pack",     1},
        {"chemical-science-pack",     1},
        {"space-science-pack",        1},
        {"agricultural-science-pack", 1},
        {"cryogenic-science-pack",    1}
      },
      time = 60
    },
    effects = {
        {type = "unlock-recipe", recipe = "gmo-yumako-seed"},
        {type = "unlock-recipe", recipe = "gmo-jellynut-seed"},
        -- Add more recipes and structures as needed
    },
}
})