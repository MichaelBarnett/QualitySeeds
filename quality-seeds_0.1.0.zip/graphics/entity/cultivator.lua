return
{
  width = 248,
  height = 336,
  shift = util.by_pixel( 0.0, -18.0),
  line_length = 8,
}
